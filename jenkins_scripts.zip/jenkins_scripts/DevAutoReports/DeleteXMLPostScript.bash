#!/bin/bash
rm -f *.xml
