#!/bin/bash
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- eServiceBuild.xml;
replace "<mavenModuleSet>" "<eServiceBuildTemp>" -- eServiceBuild.xml;
replace "</mavenModuleSet>" "</eServiceBuildTemp>" -- eServiceBuild.xml;
replace "<build>" "<row>" -- eServiceBuild.xml;
replace "<action/>" "" -- eServiceBuild.xml;
replace "<actions>" "" -- eServiceBuild.xml;
replace "<cause>" "" -- eServiceBuild.xml;
replace "<userId>" "<userid>" -- eServiceBuild.xml;
replace "</cause>" "" -- eServiceBuild.xml;
replace "</actions>" "" -- eServiceBuild.xml;
replace "<action/>" "" -- eServiceBuild.xml;
replace "<number>" "<buildnumber>" -- eServiceBuild.xml;
replace "</build>" "</row>" -- eServiceBuild.xml;
replace "<action>" "" -- eServiceBuild.xml;
replace "</action>" "" -- eServiceBuild.xml;
replace "<row>" "<row> <jobname> eService_build </jobname>" -- eServiceBuild.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- eServiceDeploy.xml;
replace "<freeStyleProject>" "<eServiceDeployTemp>" -- eServiceDeploy.xml;
replace "</freeStyleProject>" "</eServiceDeployTemp>" -- eServiceDeploy.xml;
replace "<build>" "<row>" -- eServiceDeploy.xml;
replace "<action/>" "" -- eServiceDeploy.xml;
replace "<actions>" "" -- eServiceDeploy.xml;
replace "<cause>" "" -- eServiceDeploy.xml;
replace "<userId>" "<userid>" -- eServiceDeploy.xml;
replace "</cause>" "" -- eServiceDeploy.xml;
replace "</actions>" "" -- eServiceDeploy.xml;
replace "<action/>" "" -- eServiceDeploy.xml;
replace "<number>" "<buildnumber>" -- eServiceDeploy.xml;
replace "</build>" "</row>" -- eServiceDeploy.xml;
replace "<action>" "" -- eServiceDeploy.xml;
replace "</action>" "" -- eServiceDeploy.xml;
replace "<row>" "<row> <jobname> eService_deploy </jobname>" -- eServiceDeploy.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- eServiceTrigger.xml;
replace "<freeStyleProject>" "<eServiceTriggerTemp>" -- eServiceTrigger.xml;
replace "</freeStyleProject>" "</eServiceTriggerTemp>" -- eServiceTrigger.xml;
replace "<build>" "<row>" -- eServiceTrigger.xml;
replace "<action/>" "" -- eServiceTrigger.xml;
replace "<actions>" "" -- eServiceTrigger.xml;
replace "<cause>" "" -- eServiceTrigger.xml;
replace "<userId>" "<userid>" -- eServiceTrigger.xml;
replace "</cause>" "" -- eServiceTrigger.xml;
replace "</actions>" "" -- eServiceTrigger.xml;
replace "<action/>" "" -- eServiceTrigger.xml;
replace "<number>" "<buildnumber>" -- eServiceTrigger.xml;
replace "</build>" "</row>" -- eServiceTrigger.xml;
replace "<action>" "" -- eServiceTrigger.xml;
replace "</action>" "" -- eServiceTrigger.xml;
replace "<row>" "<row> <jobname> eService_trigger </jobname>" -- eServiceTrigger.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- MPCSCommerceBuildDeploy.xml;
replace "<freeStyleProject>" "<MPCSCommerceBuildDeployTemp>" -- MPCSCommerceBuildDeploy.xml;
replace "</freeStyleProject>" "</MPCSCommerceBuildDeployTemp>" -- MPCSCommerceBuildDeploy.xml;
replace "<build>" "<row>" -- MPCSCommerceBuildDeploy.xml;
replace "<action/>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<actions>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<cause>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<userId>" "<userid>" -- MPCSCommerceBuildDeploy.xml;
replace "</cause>" "" -- MPCSCommerceBuildDeploy.xml;
replace "</actions>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<action/>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<number>" "<buildnumber>" -- MPCSCommerceBuildDeploy.xml;
replace "</build>" "</row>" -- MPCSCommerceBuildDeploy.xml;
replace "<action>" "" -- MPCSCommerceBuildDeploy.xml;
replace "</action>" "" -- MPCSCommerceBuildDeploy.xml;
replace "<row>" "<row> <jobname> MPCS_Commerce_Full_Build_Deploy </jobname>" -- MPCSCommerceBuildDeploy.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Z01MPCSTrigger.xml;
replace "<freeStyleProject>" "<Z01MPCSTriggerTemp>" -- Z01MPCSTrigger.xml;
replace "</freeStyleProject>" "</Z01MPCSTriggerTemp>" -- Z01MPCSTrigger.xml;
replace "<build>" "<row>" -- Z01MPCSTrigger.xml;
replace "<action/>" "" -- Z01MPCSTrigger.xml;
replace "<actions>" "" -- Z01MPCSTrigger.xml;
replace "<cause>" "" -- Z01MPCSTrigger.xml;
replace "<userId>" "<userid>" -- Z01MPCSTrigger.xml;
replace "</cause>" "" -- Z01MPCSTrigger.xml;
replace "</actions>" "" -- Z01MPCSTrigger.xml;
replace "<action/>" "" -- Z01MPCSTrigger.xml;
replace "<number>" "<buildnumber>" -- Z01MPCSTrigger.xml;
replace "</build>" "</row>" -- Z01MPCSTrigger.xml;
replace "<action>" "" -- Z01MPCSTrigger.xml;
replace "</action>" "" -- Z01MPCSTrigger.xml;
replace "<row>" "<row> <jobname> Z01_MPCS_BUILD_AND_DEPLOY </jobname>" -- Z01MPCSTrigger.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Z02TMUSBuild.xml;
replace "<mavenModuleSet>" "<Z02TMUSBuildTemp>" -- Z02TMUSBuild.xml;
replace "</mavenModuleSet>" "</Z02TMUSBuildTemp>" -- Z02TMUSBuild.xml;
replace "<build>" "<row>" -- Z02TMUSBuild.xml;
replace "<action/>" "" -- Z02TMUSBuild.xml;
replace "<actions>" "" -- Z02TMUSBuild.xml;
replace "<cause>" "" -- Z02TMUSBuild.xml;
replace "<userId>" "<userid>" -- Z02TMUSBuild.xml;
replace "</cause>" "" -- Z02TMUSBuild.xml;
replace "</actions>" "" -- Z02TMUSBuild.xml;
replace "<action/>" "" -- Z02TMUSBuild.xml;
replace "<number>" "<buildnumber>" -- Z02TMUSBuild.xml;
replace "</build>" "</row>" -- Z02TMUSBuild.xml;
replace "<action>" "" -- Z02TMUSBuild.xml;
replace "</action>" "" -- Z02TMUSBuild.xml;
replace "<row>" "<row> <jobname> Z02_TMUS_BUILD_JOB </jobname>" -- Z02TMUSBuild.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Z03MPCSBuild.xml;
replace "<mavenModuleSet>" "<Z03MPCSBuildTemp>" -- Z03MPCSBuild.xml;
replace "</mavenModuleSet>" "</Z03MPCSBuildTemp>" -- Z03MPCSBuild.xml;
replace "<build>" "<row>" -- Z03MPCSBuild.xml;
replace "<action/>" "" -- Z03MPCSBuild.xml;
replace "<actions>" "" -- Z03MPCSBuild.xml;
replace "<cause>" "" -- Z03MPCSBuild.xml;
replace "<userId>" "<userid>" -- Z03MPCSBuild.xml;
replace "</cause>" "" -- Z03MPCSBuild.xml;
replace "</actions>" "" -- Z03MPCSBuild.xml;
replace "<action/>" "" -- Z03MPCSBuild.xml;
replace "<number>" "<buildnumber>" -- Z03MPCSBuild.xml;
replace "</build>" "</row>" -- Z03MPCSBuild.xml;
replace "<action>" "" -- Z03MPCSBuild.xml;
replace "</action>" "" -- Z03MPCSBuild.xml;
replace "<row>" "<row> <jobname> Z03_MPCS_BUILD_JOB </jobname>" -- Z03MPCSBuild.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Z04TMUSDeploy.xml;
replace "<freeStyleProject>" "<Z04TMUSDeployTemp>" -- Z04TMUSDeploy.xml;
replace "</freeStyleProject>" "</Z04TMUSDeployTemp>" -- Z04TMUSDeploy.xml;
replace "<build>" "<row>" -- Z04TMUSDeploy.xml;
replace "<action/>" "" -- Z04TMUSDeploy.xml;
replace "<actions>" "" -- Z04TMUSDeploy.xml;
replace "<cause>" "" -- Z04TMUSDeploy.xml;
replace "<userId>" "<userid>" -- Z04TMUSDeploy.xml;
replace "</cause>" "" -- Z04TMUSDeploy.xml;
replace "</actions>" "" -- Z04TMUSDeploy.xml;
replace "<action/>" "" -- Z04TMUSDeploy.xml;
replace "<number>" "<buildnumber>" -- Z04TMUSDeploy.xml;
replace "</build>" "</row>" -- Z04TMUSDeploy.xml;
replace "<action>" "" -- Z04TMUSDeploy.xml;
replace "</action>" "" -- Z04TMUSDeploy.xml;
replace "<row>" "<row> <jobname> Z04_TMUS_DEPLOY_JOB </jobname>" -- Z04TMUSDeploy.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Z05MPCSDeploy.xml;
replace "<freeStyleProject>" "<Z05MPCSDeployTemp>" -- Z05MPCSDeploy.xml;
replace "</freeStyleProject>" "</Z05MPCSDeployTemp>" -- Z05MPCSDeploy.xml;
replace "<build>" "<row>" -- Z05MPCSDeploy.xml;
replace "<action/>" "" -- Z05MPCSDeploy.xml;
replace "<actions>" "" -- Z05MPCSDeploy.xml;
replace "<cause>" "" -- Z05MPCSDeploy.xml;
replace "<userId>" "<userid>" -- Z05MPCSDeploy.xml;
replace "</cause>" "" -- Z05MPCSDeploy.xml;
replace "</actions>" "" -- Z05MPCSDeploy.xml;
replace "<action/>" "" -- Z05MPCSDeploy.xml;
replace "<number>" "<buildnumber>" -- Z05MPCSDeploy.xml;
replace "</build>" "</row>" -- Z05MPCSDeploy.xml;
replace "<action>" "" -- Z05MPCSDeploy.xml;
replace "</action>" "" -- Z05MPCSDeploy.xml;
replace "<row>" "<row> <jobname> Z05_MPCS_DEPLOY_JOB </jobname>" -- Z05MPCSDeploy.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- GoSmartBuildDeploy.xml;
replace "<freeStyleProject>" "<GoSmartBuildDeployTemp>" -- GoSmartBuildDeploy.xml;
replace "</freeStyleProject>" "</GoSmartBuildDeployTemp>" -- GoSmartBuildDeploy.xml;
replace "<build>" "<row>" -- GoSmartBuildDeploy.xml;
replace "<action/>" "" -- GoSmartBuildDeploy.xml;
replace "<actions>" "" -- GoSmartBuildDeploy.xml;
replace "<cause>" "" -- GoSmartBuildDeploy.xml;
replace "<userId>" "<userid>" -- GoSmartBuildDeploy.xml;
replace "</cause>" "" -- GoSmartBuildDeploy.xml;
replace "</actions>" "" -- GoSmartBuildDeploy.xml;
replace "<action/>" "" -- GoSmartBuildDeploy.xml;
replace "<number>" "<buildnumber>" -- GoSmartBuildDeploy.xml;
replace "</build>" "</row>" -- GoSmartBuildDeploy.xml;
replace "<action>" "" -- GoSmartBuildDeploy.xml;
replace "</action>" "" -- GoSmartBuildDeploy.xml;
replace "<row>" "<row> <jobname> GoSmart_Deploy_Builds </jobname>" -- GoSmartBuildDeploy.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- GoSmartTagBuild.xml;
replace "<mavenModuleSet>" "<GoSmartTagBuildTemp>" -- GoSmartTagBuild.xml;
replace "</mavenModuleSet>" "</GoSmartTagBuildTemp>" -- GoSmartTagBuild.xml;
replace "<build>" "<row>" -- GoSmartTagBuild.xml;
replace "<action/>" "" -- GoSmartTagBuild.xml;
replace "<actions>" "" -- GoSmartTagBuild.xml;
replace "<cause>" "" -- GoSmartTagBuild.xml;
replace "<userId>" "<userid>" -- GoSmartTagBuild.xml;
replace "</cause>" "" -- GoSmartTagBuild.xml;
replace "</actions>" "" -- GoSmartTagBuild.xml;
replace "<action/>" "" -- GoSmartTagBuild.xml;
replace "<number>" "<buildnumber>" -- GoSmartTagBuild.xml;
replace "</build>" "</row>" -- GoSmartTagBuild.xml;
replace "<action>" "" -- GoSmartTagBuild.xml;
replace "</action>" "" -- GoSmartTagBuild.xml;
replace "<row>" "<row> <jobname> GoSmart_TagAndBuild </jobname>" -- GoSmartTagBuild.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- ARES.xml;
replace "<freeStyleProject>" "<ARESTemp>" -- ARES.xml;
replace "</freeStyleProject>" "</ARESTemp>" -- ARES.xml;
replace "<build>" "<row>" -- ARES.xml;
replace "<action/>" "" -- ARES.xml;
replace "<actions>" "" -- ARES.xml;
replace "<cause>" "" -- ARES.xml;
replace "<userId>" "<userid>" -- ARES.xml;
replace "</cause>" "" -- ARES.xml;
replace "</actions>" "" -- ARES.xml;
replace "<action/>" "" -- ARES.xml;
replace "<number>" "<buildnumber>" -- ARES.xml;
replace "</build>" "</row>" -- ARES.xml;
replace "<action>" "" -- ARES.xml;
replace "</action>" "" -- ARES.xml;
replace "<row>" "<row> <jobname> ARES </jobname>" -- ARES.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- CEPA.xml;
replace "<freeStyleProject>" "<CEPATemp>" -- CEPA.xml;
replace "</freeStyleProject>" "</CEPATemp>" -- CEPA.xml;
replace "<build>" "<row>" -- CEPA.xml;
replace "<action/>" "" -- CEPA.xml;
replace "<actions>" "" -- CEPA.xml;
replace "<cause>" "" -- CEPA.xml;
replace "<userId>" "<userid>" -- CEPA.xml;
replace "</cause>" "" -- CEPA.xml;
replace "</actions>" "" -- CEPA.xml;
replace "<action/>" "" -- CEPA.xml;
replace "<number>" "<buildnumber>" -- CEPA.xml;
replace "</build>" "</row>" -- CEPA.xml;
replace "<action>" "" -- CEPA.xml;
replace "</action>" "" -- CEPA.xml;
replace "<row>" "<row> <jobname> CEPA PAYMENT FEE </jobname>" -- CEPA.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- DLM2.xml;
replace "<freeStyleProject>" "<DLM2Temp>" -- DLM2.xml;
replace "</freeStyleProject>" "</DLM2Temp>" -- DLM2.xml;
replace "<build>" "<row>" -- DLM2.xml;
replace "<action/>" "" -- DLM2.xml;
replace "<actions>" "" -- DLM2.xml;
replace "<cause>" "" -- DLM2.xml;
replace "<userId>" "<userid>" -- DLM2.xml;
replace "</cause>" "" -- DLM2.xml;
replace "</actions>" "" -- DLM2.xml;
replace "<action/>" "" -- DLM2.xml;
replace "<number>" "<buildnumber>" -- DLM2.xml;
replace "</build>" "</row>" -- DLM2.xml;
replace "<action>" "" -- DLM2.xml;
replace "</action>" "" -- DLM2.xml;
replace "<row>" "<row> <jobname> DLM 2.0 </jobname>" -- DLM2.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- EIP.xml;
replace "<freeStyleProject>" "<EIPTemp>" -- EIP.xml;
replace "</freeStyleProject>" "</EIPTemp>" -- EIP.xml;
replace "<build>" "<row>" -- EIP.xml;
replace "<action/>" "" -- EIP.xml;
replace "<actions>" "" -- EIP.xml;
replace "<cause>" "" -- EIP.xml;
replace "<userId>" "<userid>" -- EIP.xml;
replace "</cause>" "" -- EIP.xml;
replace "</actions>" "" -- EIP.xml;
replace "<action/>" "" -- EIP.xml;
replace "<number>" "<buildnumber>" -- EIP.xml;
replace "</build>" "</row>" -- EIP.xml;
replace "<action>" "" -- EIP.xml;
replace "</action>" "" -- EIP.xml;
replace "<row>" "<row> <jobname> EIP FOR ACCESSORIES </jobname>" -- EIP.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- MARedesign.xml;
replace "<freeStyleProject>" "<MARedesignTemp>" -- MARedesign.xml;
replace "</freeStyleProject>" "</MARedesignTemp>" -- MARedesign.xml;
replace "<build>" "<row>" -- MARedesign.xml;
replace "<action/>" "" -- MARedesign.xml;
replace "<actions>" "" -- MARedesign.xml;
replace "<cause>" "" -- MARedesign.xml;
replace "<userId>" "<userid>" -- MARedesign.xml;
replace "</cause>" "" -- MARedesign.xml;
replace "</actions>" "" -- MARedesign.xml;
replace "<action/>" "" -- MARedesign.xml;
replace "<number>" "<buildnumber>" -- MARedesign.xml;
replace "</build>" "</row>" -- MARedesign.xml;
replace "<action>" "" -- MARedesign.xml;
replace "</action>" "" -- MARedesign.xml;
replace "<row>" "<row> <jobname> MA REDESIGN </jobname>" -- MARedesign.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- MARedirect.xml;
replace "<freeStyleProject>" "<MARedirectTemp>" -- MARedirect.xml;
replace "</freeStyleProject>" "</MARedirectTemp>" -- MARedirect.xml;
replace "<build>" "<row>" -- MARedirect.xml;
replace "<action/>" "" -- MARedirect.xml;
replace "<actions>" "" -- MARedirect.xml;
replace "<cause>" "" -- MARedirect.xml;
replace "<userId>" "<userid>" -- MARedirect.xml;
replace "</cause>" "" -- MARedirect.xml;
replace "</actions>" "" -- MARedirect.xml;
replace "<action/>" "" -- MARedirect.xml;
replace "<number>" "<buildnumber>" -- MARedirect.xml;
replace "</build>" "</row>" -- MARedirect.xml;
replace "<action>" "" -- MARedirect.xml;
replace "</action>" "" -- MARedirect.xml;
replace "<row>" "<row> <jobname> MA REDIRECT </jobname>" -- MARedirect.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- OTP.xml;
replace "<freeStyleProject>" "<OTPTemp>" -- OTP.xml;
replace "</freeStyleProject>" "</OTPTemp>" -- OTP.xml;
replace "<build>" "<row>" -- OTP.xml;
replace "<action/>" "" -- OTP.xml;
replace "<actions>" "" -- OTP.xml;
replace "<cause>" "" -- OTP.xml;
replace "<userId>" "<userid>" -- OTP.xml;
replace "</cause>" "" -- OTP.xml;
replace "</actions>" "" -- OTP.xml;
replace "<action/>" "" -- OTP.xml;
replace "<number>" "<buildnumber>" -- OTP.xml;
replace "</build>" "</row>" -- OTP.xml;
replace "<action>" "" -- OTP.xml;
replace "</action>" "" -- OTP.xml;
replace "<row>" "<row> <jobname> OTP </jobname>" -- OTP.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Onboarding.xml;
replace "<freeStyleProject>" "<OnboardingTemp>" -- Onboarding.xml;
replace "</freeStyleProject>" "</OnboardingTemp>" -- Onboarding.xml;
replace "<build>" "<row>" -- Onboarding.xml;
replace "<action/>" "" -- Onboarding.xml;
replace "<actions>" "" -- Onboarding.xml;
replace "<cause>" "" -- Onboarding.xml;
replace "<userId>" "<userid>" -- Onboarding.xml;
replace "</cause>" "" -- Onboarding.xml;
replace "</actions>" "" -- Onboarding.xml;
replace "<action/>" "" -- Onboarding.xml;
replace "<number>" "<buildnumber>" -- Onboarding.xml;
replace "</build>" "</row>" -- Onboarding.xml;
replace "<action>" "" -- Onboarding.xml;
replace "</action>" "" -- Onboarding.xml;
replace "<row>" "<row> <jobname> ONBOARDING </jobname>" -- Onboarding.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- PATS.xml;
replace "<freeStyleProject>" "<PATSTemp>" -- PATS.xml;
replace "</freeStyleProject>" "</PATSTemp>" -- PATS.xml;
replace "<build>" "<row>" -- PATS.xml;
replace "<action/>" "" -- PATS.xml;
replace "<actions>" "" -- PATS.xml;
replace "<cause>" "" -- PATS.xml;
replace "<userId>" "<userid>" -- PATS.xml;
replace "</cause>" "" -- PATS.xml;
replace "</actions>" "" -- PATS.xml;
replace "<action/>" "" -- PATS.xml;
replace "<number>" "<buildnumber>" -- PATS.xml;
replace "</build>" "</row>" -- PATS.xml;
replace "<action>" "" -- PATS.xml;
replace "</action>" "" -- PATS.xml;
replace "<row>" "<row> <jobname> PATS </jobname>" -- PATS.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- PHP2.xml;
replace "<freeStyleProject>" "<PHP2Temp>" -- PHP2.xml;
replace "</freeStyleProject>" "</PHP2Temp>" -- PHP2.xml;
replace "<build>" "<row>" -- PHP2.xml;
replace "<action/>" "" -- PHP2.xml;
replace "<actions>" "" -- PHP2.xml;
replace "<cause>" "" -- PHP2.xml;
replace "<userId>" "<userid>" -- PHP2.xml;
replace "</cause>" "" -- PHP2.xml;
replace "</actions>" "" -- PHP2.xml;
replace "<action/>" "" -- PHP2.xml;
replace "<number>" "<buildnumber>" -- PHP2.xml;
replace "</build>" "</row>" -- PHP2.xml;
replace "<action>" "" -- PHP2.xml;
replace "</action>" "" -- PHP2.xml;
replace "<row>" "<row> <jobname> PHP 2.0 </jobname>" -- PHP2.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- PrivacyVaultP2.xml;
replace "<freeStyleProject>" "<PrivacyVaultP2Temp>" -- PrivacyVaultP2.xml;
replace "</freeStyleProject>" "</PrivacyVaultP2Temp>" -- PrivacyVaultP2.xml;
replace "<build>" "<row>" -- PrivacyVaultP2.xml;
replace "<action/>" "" -- PrivacyVaultP2.xml;
replace "<actions>" "" -- PrivacyVaultP2.xml;
replace "<cause>" "" -- PrivacyVaultP2.xml;
replace "<userId>" "<userid>" -- PrivacyVaultP2.xml;
replace "</cause>" "" -- PrivacyVaultP2.xml;
replace "</actions>" "" -- PrivacyVaultP2.xml;
replace "<action/>" "" -- PrivacyVaultP2.xml;
replace "<number>" "<buildnumber>" -- PrivacyVaultP2.xml;
replace "</build>" "</row>" -- PrivacyVaultP2.xml;
replace "<action>" "" -- PrivacyVaultP2.xml;
replace "</action>" "" -- PrivacyVaultP2.xml;
replace "<row>" "<row> <jobname> PRIVACY VAULT PHASE 2 </jobname>" -- PrivacyVaultP2.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- SelfServeLeads.xml;
replace "<freeStyleProject>" "<SelfServeLeadsTemp>" -- SelfServeLeads.xml;
replace "</freeStyleProject>" "</SelfServeLeadsTemp>" -- SelfServeLeads.xml;
replace "<build>" "<row>" -- SelfServeLeads.xml;
replace "<action/>" "" -- SelfServeLeads.xml;
replace "<actions>" "" -- SelfServeLeads.xml;
replace "<cause>" "" -- SelfServeLeads.xml;
replace "<userId>" "<userid>" -- SelfServeLeads.xml;
replace "</cause>" "" -- SelfServeLeads.xml;
replace "</actions>" "" -- SelfServeLeads.xml;
replace "<action/>" "" -- SelfServeLeads.xml;
replace "<number>" "<buildnumber>" -- SelfServeLeads.xml;
replace "</build>" "</row>" -- SelfServeLeads.xml;
replace "<action>" "" -- SelfServeLeads.xml;
replace "</action>" "" -- SelfServeLeads.xml;
replace "<row>" "<row> <jobname> Self_Serve_Leads </jobname>" -- SelfServeLeads.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- T3.xml;
replace "<freeStyleProject>" "<T3Temp>" -- T3.xml;
replace "</freeStyleProject>" "</T3Temp>" -- T3.xml;
replace "<build>" "<row>" -- T3.xml;
replace "<action/>" "" -- T3.xml;
replace "<actions>" "" -- T3.xml;
replace "<cause>" "" -- T3.xml;
replace "<userId>" "<userid>" -- T3.xml;
replace "</cause>" "" -- T3.xml;
replace "</actions>" "" -- T3.xml;
replace "<action/>" "" -- T3.xml;
replace "<number>" "<buildnumber>" -- T3.xml;
replace "</build>" "</row>" -- T3.xml;
replace "<action>" "" -- T3.xml;
replace "</action>" "" -- T3.xml;
replace "<row>" "<row> <jobname> T3 </jobname>" -- T3.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Treadstone.xml;
replace "<freeStyleProject>" "<TreadstoneTemp>" -- Treadstone.xml;
replace "</freeStyleProject>" "</TreadstoneTemp>" -- Treadstone.xml;
replace "<build>" "<row>" -- Treadstone.xml;
replace "<action/>" "" -- Treadstone.xml;
replace "<actions>" "" -- Treadstone.xml;
replace "<cause>" "" -- Treadstone.xml;
replace "<userId>" "<userid>" -- Treadstone.xml;
replace "</cause>" "" -- Treadstone.xml;
replace "</actions>" "" -- Treadstone.xml;
replace "<action/>" "" -- Treadstone.xml;
replace "<number>" "<buildnumber>" -- Treadstone.xml;
replace "</build>" "</row>" -- Treadstone.xml;
replace "<action>" "" -- Treadstone.xml;
replace "</action>" "" -- Treadstone.xml;
replace "<row>" "<row> <jobname> TREADSTONE </jobname>" -- Treadstone.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- Viper.xml;
replace "<freeStyleProject>" "<ViperTemp>" -- Viper.xml;
replace "</freeStyleProject>" "</ViperTemp>" -- Viper.xml;
replace "<build>" "<row>" -- Viper.xml;
replace "<action/>" "" -- Viper.xml;
replace "<actions>" "" -- Viper.xml;
replace "<cause>" "" -- Viper.xml;
replace "<userId>" "<userid>" -- Viper.xml;
replace "</cause>" "" -- Viper.xml;
replace "</actions>" "" -- Viper.xml;
replace "<action/>" "" -- Viper.xml;
replace "<number>" "<buildnumber>" -- Viper.xml;
replace "</build>" "</row>" -- Viper.xml;
replace "<action>" "" -- Viper.xml;
replace "</action>" "" -- Viper.xml;
replace "<row>" "<row> <jobname> VIPER </jobname>" -- Viper.xml;

#
replace "This XML file does not appear to have any style information associated with it. The document tree is shown below." "" -- WRAP.xml;
replace "<freeStyleProject>" "<WRAPTemp>" -- WRAP.xml;
replace "</freeStyleProject>" "</WRAPTemp>" -- WRAP.xml;
replace "<build>" "<row>" -- WRAP.xml;
replace "<action/>" "" -- WRAP.xml;
replace "<actions>" "" -- WRAP.xml;
replace "<cause>" "" -- WRAP.xml;
replace "<userId>" "<userid>" -- WRAP.xml;
replace "</cause>" "" -- WRAP.xml;
replace "</actions>" "" -- WRAP.xml;
replace "<action/>" "" -- WRAP.xml;
replace "<number>" "<buildnumber>" -- WRAP.xml;
replace "</build>" "</row>" -- WRAP.xml;
replace "<action>" "" -- WRAP.xml;
replace "</action>" "" -- WRAP.xml;
replace "<row>" "<row> <jobname> WARP </jobname>" -- WRAP.xml;
