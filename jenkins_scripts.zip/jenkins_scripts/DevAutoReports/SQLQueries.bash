#!/bin/bash
mysql -u root -ppassword << EOF
use audit_reports;

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/eServiceBuild.xml' INTO TABLE eServiceBuild ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/eServiceDeploy.xml' INTO TABLE eServiceDeploy ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/eServiceTrigger.xml' INTO TABLE eServiceTrigger ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/ARES.xml' INTO TABLE ARES ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/CEPA.xml' INTO TABLE CEPA ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/DLM2.xml' INTO TABLE DLM2 ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/EIP.xml' INTO TABLE EIP ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/GoSmartBuildDeploy.xml' INTO TABLE GoSmartBuildDeploy ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/GoSmartTagBuild.xml' INTO TABLE GoSmartTagBuild ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/MARedesign.xml' INTO TABLE MARedesign ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/MARedirect.xml' INTO TABLE MARedirect ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/MPCSCommerceBuildDeploy.xml' INTO TABLE MPCSCommerceBuildDeploy ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/OTP.xml' INTO TABLE OTP ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Onboarding.xml' INTO TABLE Onboarding ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/PATS.xml' INTO TABLE PATS ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/PHP2.xml' INTO TABLE PHP2 ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/PrivacyVaultP2.xml' INTO TABLE PrivacyVaultP2 ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/SelfServeLeads.xml' INTO TABLE SelfServeLeads ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/T3.xml' INTO TABLE T3 ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Treadstone.xml' INTO TABLE Treadstone ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Viper.xml' INTO TABLE Viper ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/WRAP.xml' INTO TABLE WRAP ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Z01MPCSTrigger.xml' INTO TABLE Z01MPCSTrigger ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Z02TMUSBuild.xml' INTO TABLE Z02TMUSBuild ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Z03MPCSBuild.xml' INTO TABLE Z03MPCSBuild ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Z04TMUSDeploy.xml' INTO TABLE Z04TMUSDeploy ROWS IDENTIFIED BY '<row>';

LOAD XML LOCAL INFILE '/u01/jenkins/jobs/DevAutoReports/workspace/Z05MPCSDeploy.xml' INTO TABLE Z05MPCSDeploy ROWS IDENTIFIED BY '<row>';

EOF
