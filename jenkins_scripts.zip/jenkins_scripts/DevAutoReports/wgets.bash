wget "http://172.28.49.65:8080/job/eService_trigger/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=eServiceTrigger.xml;

wget "http://172.28.49.65:8080/job/eService_build/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=eServiceBuild.xml;

wget "http://172.28.49.65:8080/job/eService_deploy/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=eServiceDeploy.xml;

wget "http://172.28.49.65:8080/job/MPCS_Commerce_Full_Build_Deploy/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=MPCSCommerceBuildDeploy.xml;

wget "http://172.28.49.65:8080/job/Z01_MPCS_BUILD_AND_DEPLOY/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Z01MPCSTrigger.xml;

wget "http://172.28.49.65:8080/job/Z02_TMUS_BUILD_JOB/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Z02TMUSBuild.xml;

wget "http://172.28.49.65:8080/job/Z03_MPCS_BUILD_JOB/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Z03MPCSBuild.xml;

wget "http://172.28.49.65:8080/job/Z04_TMUS_DEPLOY_JOB/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Z04TMUSDeploy.xml;

wget "http://172.28.49.65:8080/job/Z05_MPCS_DEPLOY_JOB/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Z05MPCSDeploy.xml;

wget "http://172.28.49.65:8080/job/GoSmart_Deploy_Builds/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=GoSmartBuildDeploy.xml;

wget "http://172.28.49.65:8080/job/GoSmart_TagAndBuild/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=GoSmartTagBuild.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/ARES/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=ARES.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/CEPA%20PAYMENT%20FEE/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=CEPA.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/DLM%202.0/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=DLM2.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/EIP%20FOR%20ACCESSORIES/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=EIP.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/MA%20REDESIGN/api/xml'?'tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=MARedesign.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/MA%20REDIRECT/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=MARedirect.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/OTP/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=OTP.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/ONBOARDING/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Onboarding.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/PATS/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=PATS.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/PHP%202.0/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=PHP2.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/PRIVACY%20VAULT%20PHASE%202/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=PrivacyVaultP2.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/Self_Serve_Leads/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=SelfServeLeads.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/T3/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=T3.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/TREADSTONE/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Treadstone.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/VIPER/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=Viper.xml;

wget "http://172.28.49.65:8080/view/Self%20Service/job/Stack%20Self%20Serve/job/WARP/api/xml?tree=builds[number,status,timestamp,id,result,actions[causes[userId]]]" --output-document=WRAP.xml;