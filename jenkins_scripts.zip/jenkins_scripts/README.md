# Jenkins Scripts

A central version-controlled source for Jenkins' job scripts.

## The Goal

As our Jenkins jobs are becoming more complex and integrated with core
scripts in tmo_config, the ability to track and explain changes through
commit history and test new changes using branches in git becomes
increasingly valuable. Hence, the configuration history plugin utilized
by Jenkins is no longer fully sufficient to manage changes for our
scripts, and git becomes a much better option. In making this move, we
gain better control and visibility regarding how these scripts change
and can better explain changes using commit messages.

## Usage

1. Create a hierarchy within this directory which matches that of the
   hierarchy in Jenkins.  
   e.g. If the job is not in any folders, create the directory
   /tmo_config/jenkins_scripts/<u>{job_name}</u>; if the job is under
   the Test/Temp/ folder, create the directory
   /tmo_config/jenkins_scripts/Test/Temp/<u>{job_name}</u>
2. Create each of your scripts files. For all imported scripts, the
   naming schema is <u>script_{number}</u>, where <u>{number}</u>
   begins at 1, and increases for each script involved with a specific
   job.  
   These scripts should begin with a line including a
   [shebang](https://en.wikipedia.org/wiki/Shebang_%28Unix%29) and the
   program which should be used to run it. For normal shell scripts,
   this line should read as follows:
        
        #!/bin/bash
        
    ***It is highly recommended*** to enable trace logging for these
    scripts, as it is very useful for Jenkins logs and debugging
    scripts. This can be done by running `set -x`, or by modifying the
    shebang header of the file with this shorthand:
        
        #!/bin/bash -x
        
    *Note:* All script files must be committed such that they will have
    executable permissions on the server. To do this in git, run
    `git update-index --chmod=+x <file>` and commit the change.
3. To call a script from its Jenkins job, simply replace the section
   where it would be typed in the job with the following command:
        
        /mnt/ebs/disk1/tmo_config/jenkins_scripts/"${JOB_NAME}"/script_1
        
    where `script_1` is the name of the file you wish to call. This will
    automatically expand to run the file in its corresponding folder
    within tmo_config.
