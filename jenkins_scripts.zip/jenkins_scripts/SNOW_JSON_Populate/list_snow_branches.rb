#!/bin/env ruby

require 'json'
require 'base64'
require 'net/http'

def cq_svn_path
   branch_type = `svn list http://comsvn3a.eservice.tmobile.com/eservice/branches/ | sed 's/.$//'`.split
   for type in branch_type
       branches = `svn list http://comsvn3a.eservice.tmobile.com/eservice/branches/#{type} | sed 's/.$//'`.split
       for b in branches
          object = Hash.new
          object["u_branch_type"]=type
          object["u_branch_name"]=b
          data= object.to_json
          puts data
		`curl --user jenkins@svc:SyfHz7_RX \
		--header "Content-Type:application/json" \
		--header "Accept: application/json" \
		--request POST \
		--data '#{data}' \
		https://tmus.service-now.com/api/now/table/u_jenkins_import`
		end
   end
end
cq_svn_path
