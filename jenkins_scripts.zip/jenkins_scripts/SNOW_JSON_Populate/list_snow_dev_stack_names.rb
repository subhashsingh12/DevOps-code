#!/bin/env ruby

require 'json'
require_relative '../scripts/connection_info'

$include_prod = true

$logger.level = Logger::WARN

servers = Hash.new

ConnectionInfo.query_servers( { "application" => /tmo/, "cf_stack" => /.*(dev|ufo|oops)$/ } ).each do |s|
        begin
                servers[s.to_s] = s if !servers.has_key?(s.dns_name)
        rescue => ex
                $logger.error "#{s.dns_name} Exception: #{ex}"
                #ex.backtrace.each_with_index { |x,i| $logger.error "   #{i}: #{x}"}
        end
end

begin
        File.open('/mnt/ebs/disk1/jenkinshome/properties/tmo_dev_stack_only.properties', 'wb') { |f|
                        f.print "key="
                        arr = []
                        servers.sort.each do |k,v|
                        arr.push "cf_stack_#{v.cf_stack}"
                        end
                        f.print(arr.uniq.sort.join(","))
                }
end


servers = Hash.new



mapping_path = File.expand_path('/mnt/ebs/disk1/jenkinshome/properties/tmo_dev_stack_only.properties',File.expand_path(File.dirname(__FILE__)))
# $logger.debug "project: mapping_path=#{mapping_path}"
parse = ""
if File.exist?(mapping_path)
        File.open(mapping_path).each do |line|
        	    parse=line[4..-1].split(',')
        end
        parse.each do |stackname|
	        begin
	            File.open("../../scripts/branch_project_mapping.txt") do |f|
	                    f.each_line do |line|
	                            $key, $value, b, e = line.split ':', 4
	                            stackname.upcase!
	                            if stackname.include? $key
	                                    project = $value
	                                    puts stackname
	                                    puts $value
	                                    break
	                            else
	                                    project = stackname
	                            end
	                            servers["u_display_name"] = role
						        servers["u_name"] = stack
								udata = Hash.new
								data=servers.to_json
						         	puts data
								`curl --user jenkins@svc:SyfHz7_RX \
								--header "Content-Type:application/json" \
								--header "Accept: application/json" \
								--request POST \
								--data '#{data}' \
								https://tmus.service-now.com/api/now/table/u_jenkins_destination_stack_import`
	                    end
	            end
	        rescue
	                puts "mapping file does not exist"
	        end
	    end
end


