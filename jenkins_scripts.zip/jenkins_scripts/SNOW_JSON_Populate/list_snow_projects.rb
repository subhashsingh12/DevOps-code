#!/bin/env ruby

require 'json'
#require_relative 'connection_info'

# $include_prod = true

# $logger.level = Logger::DEBUG

servers = Hash.new

# ConnectionInfo.query_servers( { "application" => /tmo/ } ).each do |s|
#         begin
#                 servers << s.cf_stack if !s.project.nil? && s.cf_stack =~ /dev$/
#         rescue => ex
#                 $logger.error "#{s.dns_name} Exception: #{ex}"
#                 #ex.backtrace.each_with_index { |x,i| $logger.error "   #{i}: #{x}"}
#         end
# end

# puts JSON.pretty_generate(servers.uniq.sort)

mapping_path = File.expand_path('../../scripts/branch_project_mapping.txt',File.expand_path(File.dirname(__FILE__)))
# $logger.debug "project: mapping_path=#{mapping_path}"
if File.exist?(mapping_path)
        File.open(mapping_path).each do |line|
                role,proj,branch,stack = line.split(':').map { |l| l.strip } rescue 
                STDERR.puts "role=#{role}, proj=#{proj}, branch=#{branch}, stack=#{stack}"	
	        puts "#{proj}"
	        servers["u_name"] = proj
	        udata = Hash.new
		data=servers.to_json
         	puts data
		`curl --user jenkins@svc:SyfHz7_RX \
		--header "Content-Type:application/json" \
		--header "Accept: application/json" \
		--request POST \
		--data '#{data}' \
		https://tmus.service-now.com/api/now/table/u_jenkins_project_import`
        end
end


