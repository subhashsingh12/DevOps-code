#!/bin/bash
rm -f svn.json
echo -n 'curl --user jenkins@svc:SyfHz7_RX \
--header "Content-Type:application/json" \
--header "Accept: application/json" \
--request POST--data '\''' >> svn.json
last=$(svn ls http://comsvn3a.eservice.t-mobile.com/eservice/branches/ | tail -n 1 | sed 's/.$//')
echo -n '{"u_data":"Branch Type:' >>svn.json;svn ls http://comsvn3a.eservice.t-mobile.com/eservice/branches | sed 's/\///' | tr '\n' ',' | sed 's/.$//'>>json.txt; echo '",' >>svn.json
rm -f branchtypes.txt
svn ls http://comsvn3a.eservice.t-mobile.com/eservice/branches/ | sed 's/.$//' > branchtypes.txt
while read p; do
 echo -n '"'$p'":"' >> svn.json
 if [ "$p" != "$last" ]; then
  svn ls http://comsvn3a.eservice.t-mobile.com/eservice/branches/$p | sed 's/\///' | tr '\n' ','| sed 's/.$//' >> svn.json;echo '",' >> svn.json
  continue
 fi
 if [ "$p" = "$last" ]; then
  svn ls http://comsvn3a.eservice.t-mobile.com/eservice/branches/$p | sed 's/\///' | tr '\n' ','| sed 's/.$//' >> svn.json;echo '"}'\''https://tmusdev.service-now.com/api/now/table/u_jenkins_import' >> svn.json
  continue
 fi
done <branchtypes.txt
