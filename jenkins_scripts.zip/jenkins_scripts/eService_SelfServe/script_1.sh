#!/bin/bash -x

# set tag checkout URL fragment
tag_url=${TMUS_BUILD_BRANCH}
url=${TMUS_BUILD_BRANCH}/${TMUS_SUB_BRANCH}

#set start time/date
pstDate=`TZ=PST8CDT date "+%Y%m%d%H%M"`
tagDate=`date +"%m-%d-%y"`
tagTime=`TZ=PST8CDT date "+%H:%M"`PST

# set tag name, build url
tag_name="tmus_"${TMUS_VERSION}"_"$pstDate
build_url=${tag_url}/${tag_name}

# description-setter string
echo "DESCRIPTION="${url}","${tag_name}"="
pipeline=$PIPELINE_NUMBER

# echo tag properties
echo "REQUEST_NUMBER="$REQUEST_NUMBER > /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "REQUEST_USER="$REQUEST_USER >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "DESTINATION_STACK="$DESTINATION_STACK >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "BRANCH_TYPE="$BRANCH_TYPE >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "BRANCH="$BRANCH >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "SYS_ID="$SYS_ID >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "GROUP_EMAIL="$GROUP_EMAIL >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "APPROVER_EMAIL="$APPROVER_EMAIL >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "US_DEFECTS="$US_DEFECTS >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "PROJECT="$PROJECT >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties
echo "START_TIME="$pstDate >> /mnt/ebs/disk1/jenkinshome/properties/selfservebuild-"${pipeline}".properties

